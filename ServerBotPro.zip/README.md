# Glowstone-serverbot
 Official server bot download

 Buy the license at https://discord.gg/pYXsJxkBU3

 1# Download the latest version of nodejs (16.6 +)

2# Run the BUILD.bat batch file (For mac/linux users, run the command `npm install`)

3# Run the HWID_Check.bat batch file (For mac/linux users, run the command `node HWID_Check.js`)

4# Get your HWID added to the database in the discord database

5# Run the run.bat batch file (For mac/linux users, run the command `node index.js`) to start the program